export interface AppConfig {    
    API_ENDPOINT : string   
  }  
  
export const CONFIG: AppConfig = {
    API_ENDPOINT:'https://spacelaunchnow.me/api/3.3.0/launch/'
  };